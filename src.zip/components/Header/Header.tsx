import style from './index.module.scss';

export default function Header() {
    return <div className={style.navi}>MetaphorViz</div>;
}
