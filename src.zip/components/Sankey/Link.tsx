// Types
import { SankeyLinkExtended, SankeyNodeExtended, SankeyData, SankeyLink } from '../../types/sankey';
import './Sankey.css';
import { FC, useState, useEffect, useCallback } from 'react';
import { Utility } from '../../utils/sankey/basics';
import { SourceTargetIdLinksDict } from './Sankey';
import { useRef, Component } from 'react';
import * as d3 from 'd3';
import { brush, brushY } from 'd3-brush';
import Brushes from './Brushes';
// import Brush from './Brush';
import styled from 'styled-components';
import { numberTypeAnnotation } from '@babel/types';
// import { Types } from './AreaChartHelper';
import useWindowDimensions from './WindowDimensions';
import ChartHelper from './AreaChartHelper';
import { link, linkSync } from 'fs';
import { calcSankeyNodes, calcSankeyLinks } from '../../utils/';
import { BrushBehavior } from 'd3-brush';
import { render } from '@testing-library/react';
import * as _ from 'lodash';

const NodePos = styled.g`
    margin-top: 102px;
`;

const NodeName = styled.text`
    margin-top: 12px;
`;

// Props
interface LinkProps {
    node: SankeyNodeExtended;
    nodes: SankeyNodeExtended[];
    link: SankeyLinkExtended;
    originData: SankeyData;
    setOriginData: React.Dispatch<React.SetStateAction<SankeyData>>;
    sourceTargetIdLinksDict: SourceTargetIdLinksDict;
}

export namespace Types {
    export type Data = {
        date?: string;
        value?: number;
    };
    export type Dimensions = {
        width: number;
        height: number;
        margin: {
            left: number;
            right: number;
            top: number;
            bottom: number;
        };
        boundedWidth?: number;
        boundedHeight?: number;
    };
}

interface IBrushProps {
    dimensions: Types.Dimensions;
    data: Types.Data[];
    node?: SankeyNodeExtended;
    link?: SankeyLinkExtended;
    propertiesNames: string[];
    onBrushUpdateData: (value: Date[]) => void;
    stroke: string;
    x: number;
    y: number;
}

// Component
export const Link = ({ nodes, node, link, originData, sourceTargetIdLinksDict, setOriginData }: LinkProps) => {
    const colorLink = [];
    const nonColorLink = [];
    // highlight = hover
    //linksDict의 색상을 나눠야하는 상황
    //arrLink = 색상을 가지고 있는 링크들의 집합.

    //앞에서 구한 같은 process의 link도 가져와여함
    //target의 target 기준 link
    // 고려사항 1) same color 2) same process
    // 앞 뒤 비교를 위한 link의 정보가 있어야함.

    // console.log(originData);
    const renderingData: SankeyData = { ...originData }; // 확인 (데이터 내용)
    const testLink: SankeyLinkExtended = { ...link };
    const afterLinks = [testLink] as SankeyLinkExtended[];
    // a= 필요한 정보만 가져온 link 배열
    const a: SankeyLinkExtended[] = [];
    const b: SankeyLinkExtended[] = [];
    const c: SankeyLinkExtended[] = [];
    const d: SankeyLinkExtended[] = [];
    const e: SankeyLinkExtended[] = [];
    //@ts-ignore
    const f = [];
    const trashA = [];
    // let arrLink = afterLinks.find((recursiveLink, i) => {
    //     if (link.target === recursiveLink.target || link.source === recursiveLink.source) {
    //         const wantSourceLinkNumberPart = `${recursiveLink.source}`; // 0, source
    //         const wantSourceLinkPart = `${recursiveLink.sourceNode.name}`;
    //         const wantTargetLinkNumberPart = `${recursiveLink.target}`; // 2, target
    //         const wantTargetLinkPart = `${recursiveLink.targetNode.name}`;
    //         const wantProcessLinkPart = `${recursiveLink.process}`;
    //         const wantIdLinkPart = `${recursiveLink.id}`;
    //         if (recursiveLink.color !== 'grayLinkColor') {
    //             if (recursiveLink.target <= 30) {
    //                 //@ts-ignore
    //                 return a.push(wantSourceLinkNumberPart, wantSourceLinkPart, wantTargetLinkNumberPart, wantTargetLinkPart, wantProcessLinkPart);
    //             } else if (recursiveLink.target <= 49) {
    //                 //@ts-ignore
    //                 return b.push(wantSourceLinkNumberPart, wantSourceLinkPart, wantTargetLinkNumberPart, wantTargetLinkPart, wantProcessLinkPart);
    //             } else if (recursiveLink.target <= 75) {
    //                 //@ts-ignore
    //                 return c.push(wantSourceLinkNumberPart, wantSourceLinkPart, wantTargetLinkNumberPart, wantTargetLinkPart, wantProcessLinkPart);
    //             } else if (recursiveLink.target <= 82) {
    //                 //@ts-ignore
    //                 return d.push(wantSourceLinkNumberPart, wantSourceLinkPart, wantTargetLinkNumberPart, wantTargetLinkPart, wantProcessLinkPart);
    //             } else if (recursiveLink.target <= 99) {
    //                 //@ts-ignore
    //                 return e.push(wantSourceLinkNumberPart, wantSourceLinkPart, wantTargetLinkNumberPart, wantTargetLinkPart, wantProcessLinkPart);
    //             }
    //         }
    //     } else return null;
    // });
    // console.log(a);
    // console.log(b);
    const hihihi = [...a, ...b, ...c, ...d, ...e];
    // console.log(hihihi);

    // let intersection = a.filter((x) => {
    //     //@ts-ignore
    //     b[2].includes(x);
    // });
    //@ts-ignore

    const obj1 = Object.assign({}, a); // firstLink
    const obj2 = Object.assign({}, a, b); // secondLink
    const obj3 = Object.assign({}, a, b, c); // thirdLink
    const obj4 = Object.assign({}, a, b, c, d);
    const obj5 = Object.assign({}, a, b, c, d, e);
    const findFifthColoredLink = renderingData.links.filter((colored) => {
        if (colored.color !== 'grayLinkColor') {
            if (colored.target <= 99) {
                return true;
            } else return false;
        }
    }); // for Vis_tech
    // console.log(findFifthColoredLink);
    // hover, click 기준 노드의 위치에 의해 title을 설정.

    const titleTag = () => {
        if (link.color != 'grayLinkColor') {
            //@ts-ignore
            if (link.target <= 30) {
                // return `${link.paperName}: ${link.sourceNode.name} → ${link.targetNode.name}: ${link.value}`;
                //@ts-ignore
                return `${obj1[1]}->${obj1[3]}`;
                // return `${arrLink.sourceNode.name}→${arrLink.targetNode.name}, ${arrLink.process}`;
            } else if (31 <= link.target && link.target <= 49) {
                //prevLink.sourceNode.name, prevLink = findFrontLink에서의 동일한 sourceNode.name을 가지는 링크
                //@ts-ignore
                return `${obj1[1]}→${link.sourceNode.name}→${link.targetNode.name}`;
            } else if (link.target >= 50 && link.target <= 75) {
                //@ts-ignore
                return `${a}→${link.sourceNode.name}→${link.targetNode.name}`;
            } else if (link.target >= 76 && link.target <= 82) {
                //@ts-ignore
                return `${a}→${link.sourceNode.name}→${link.targetNode.name}`;
            } else if (link.target >= 83 && link.target <= 99) {
                //@ts-ignore
                return `${a}→${link.sourceNode.name}→${link.targetNode.name}`;
            } else return 'error';
        }
    };

    const onClickFunction = () => {
        const renderingData: SankeyData = { ...originData };
        renderingData.positionStatus = 'clicked';
        renderingData.links = renderingData.links.map((link) => {
            return { ...link };
        });

        const selectedLinkPart = sourceTargetIdLinksDict[`${link.source}-${link.target}-${link.valueid}-${link.paperName}`];

        let results = [];

        renderingData.links.forEach((renderingLink) => {
            renderingLink.color = 'grayLinkColor';
            // renderingLink.valueid = undefined; // 초기 상태
            renderingLink.status = undefined;
            // console.log(renderingData.links.length);
            selectedLinkPart.forEach((linkPart) => {
                // if (link.color === 'grayLinkColor') {
                //     return false;
                // }
                if (renderingLink.id && renderingLink.id === linkPart.id) {
                    //TODO inter, rep에 속하는지 판단만 하면 되는 상황
                    if (renderingLink.target >= 0 && renderingLink.target <= 7) {
                        renderingLink.color = 'targetLinkColor';
                        // renderingLink.valueid = 'selected';
                        //renderingLink.status = 'selected';
                    }
                    if (renderingLink.target >= 8 && renderingLink.target <= 10) {
                        renderingLink.color = 'targetLinkOneColor';
                        // renderingLink.valueid = 'selected';
                        //renderingLink.status = 'selected';
                    }
                    if (renderingLink.target >= 11 && renderingLink.target <= 15) {
                        renderingLink.color = 'targetLinkTwoColor';
                        // renderingLink.valueid = 'selected';
                        //renderingLink.status = 'selected';
                    }
                    if (renderingLink.target >= 16 && renderingLink.target <= 20) {
                        renderingLink.color = 'targetLinkThreeColor';
                        // renderingLink.valueid = 'selected';
                        //renderingLink.status = 'selected';
                    }
                    if (renderingLink.target >= 21 && renderingLink.target <= 30) {
                        renderingLink.color = 'targetLinkFourColor';
                        // renderingLink.valueid = 'selected';
                        //renderingLink.status = 'selected';
                    }
                    if ((renderingLink.target >= 31 && renderingLink.target <= 33) || (renderingLink.source >= 31 && renderingLink.source <= 33)) {
                        renderingLink.color = 'intOneLinkColor';
                        // renderingLink.valueid = 'selected';
                        //renderingLink.status = 'selected';
                    }
                    if (renderingLink.target === 34 || renderingLink.source === 34) {
                        renderingLink.color = 'intOneLightLinkColor';
                        // renderingLink.valueid = 'selected';
                        //renderingLink.status = 'selected';
                    }
                    if (renderingLink.target === 35 || renderingLink.source === 35) {
                        renderingLink.color = 'intOneLight2LinkColor';
                        // renderingLink.valueid = 'selected';
                        //renderingLink.status = 'selected';
                    }
                    if ((renderingLink.target >= 36 && renderingLink.target <= 38) || (renderingLink.source >= 36 && renderingLink.source <= 38)) {
                        renderingLink.color = 'intOneLight3LinkColor';
                        // renderingLink.valueid = 'selected';
                        //renderingLink.status = 'selected';
                    }
                    if (renderingLink.target === 39 || renderingLink.source === 39) {
                        renderingLink.color = 'intTwoLinkColor';
                        // renderingLink.valueid = 'selected';
                        //renderingLink.status = 'selected';
                    }
                    if (renderingLink.target === 40 || renderingLink.source === 40) {
                        renderingLink.color = 'intTwoLightLinkColor';
                        // renderingLink.valueid = 'selected';
                        //renderingLink.status = 'selected';
                    }
                    if (renderingLink.target === 41 || renderingLink.source === 41) {
                        renderingLink.color = 'intThreeLinkColor';
                        // renderingLink.valueid = 'selected';
                        //renderingLink.status = 'selected';
                    }
                    if (renderingLink.target === 42 || renderingLink.source === 42) {
                        renderingLink.color = 'intThreeLightLinkColor';
                        // renderingLink.valueid = 'selected';
                        //renderingLink.status = 'selected';
                    }
                    if (renderingLink.target === 43 || renderingLink.source === 43) {
                        renderingLink.color = 'intThreeLight1LinkColor';
                        // renderingLink.valueid = 'selected';
                        //renderingLink.status = 'selected';
                    }
                    if (renderingLink.target === 44 || renderingLink.source === 44) {
                        renderingLink.color = 'intThreeLight2LinkColor';
                        // renderingLink.valueid = 'selected';
                        //renderingLink.status = 'selected';
                    }
                    if (renderingLink.target === 45 || renderingLink.source === 45) {
                        renderingLink.color = 'intFourLinkColor';
                        // renderingLink.valueid = 'selected';
                        //renderingLink.status = 'selected';
                    }
                    if (renderingLink.target === 46 || renderingLink.source === 46) {
                        renderingLink.color = 'intFiveLinkColor';
                        // renderingLink.valueid = 'selected';
                        //renderingLink.status = 'selected';
                    }
                    if ((renderingLink.target >= 47 && renderingLink.target <= 48) || (renderingLink.source >= 47 && renderingLink.source <= 48)) {
                        renderingLink.color = 'intFiveLightLinkColor';
                        // renderingLink.valueid = 'selected';
                        //renderingLink.status = 'selected';
                    }
                    if (renderingLink.target === 49 || renderingLink.source === 49) {
                        renderingLink.color = 'intFiveLight2LinkColor';
                        // renderingLink.valueid = 'selected';
                        //renderingLink.status = 'selected';
                    }
                    if (renderingLink.target >= 76 && renderingLink.target < 83) {
                        renderingLink.color = 'repVisVarColor';
                        // renderingLink.valueid = 'selected';
                        //renderingLink.status = 'selected';
                    }
                    if (renderingLink.target > 82 && renderingLink.target < 100) {
                        renderingLink.color = 'repVisTechColor';
                        // renderingLink.valueid = 'selected';
                        //renderingLink.status = 'selected';
                    }
                }
            });
        });
        const recursiveFunction = selectedLinkPart.forEach((selectedLinkPart) => {
            findFrontLinks({
                // 앞 link 탐색
                linkPart: selectedLinkPart,
                renderingData,
            });
            findBackLinks({
                // 뒷 link 탐색
                linkPart: selectedLinkPart,
                renderingData,
            });
        });
        if (link.color === 'grayLinkColor') {
            setOriginData(originData);
        } else setOriginData(renderingData);
    };

    return (
        <>
            <path
                className="link"
                d={link.path}
                stroke={`url(#${link.color})`}
                strokeWidth={link.value}
                fill="none"
                //TODO link mouseenter, mouseout
                onMouseEnter={() => {}}
                // onMouseEnter={() => {
                //     const renderingData: SankeyData = { ...originData };
                //     renderingData.positionStatus = 'clicked';
                //     renderingData.links = renderingData.links.map((link) => {
                //         return { ...link };
                //     });

                //     const selectedLinkPart = sourceTargetIdLinksDict[`${link.source}-${link.target}-${link.valueid}-${link.paperName}`];
                //     selectedLinkPart.forEach((selectedLinkPart) => {
                //         findFrontLinks({
                //             // 앞 link 탐색
                //             linkPart: selectedLinkPart,
                //             renderingData,
                //             interactionType: 'hover',
                //         });
                //         console.log('asdads');
                //         findBackLinks({
                //             // 뒷 link 탐색
                //             linkPart: selectedLinkPart,
                //             renderingData,
                //         });
                //         if (link.color === 'grayLinkColor') {
                //             setOriginData(originData);
                //         } else setOriginData(renderingData);
                //     });
                // }}
                // onMouseLeave={() => {
                //     const renderingData: SankeyData = { ...originData };
                //     renderingData.positionStatus = 'clicked';
                //     renderingData.links = renderingData.links.map((link) => {
                //         return { ...link };
                //     });

                //     const selectedLinkPart = sourceTargetIdLinksDict[`${link.source}-${link.target}-${link.valueid}-${link.paperName}`];
                //     selectedLinkPart.forEach((selectedLinkPart) => {
                //         findFrontLinks({
                //             // 앞 link 탐색
                //             linkPart: selectedLinkPart,
                //             renderingData,
                //             interactionType: 'click',
                //         });
                //         console.log('asdads');
                //         findBackLinks({
                //             // 뒷 link 탐색
                //             linkPart: selectedLinkPart,
                //             renderingData,
                //         });
                //         if (link.color === 'grayLinkColor') {
                //             setOriginData(originData);
                //         } else setOriginData(renderingData);
                //     });
                // }}
                onClick={onClickFunction}
            >
                {/*
                링크 process보여주기 위해 사용될 변수: link.source | link.target
                같이 이어주는걸 보여주기위해 사용될 변수: process
                 */}

                {link.color !== 'grayLinkColor' && link.process ? (
                    // <title className="info">{`${link.process}, ${link.paperName}: ${link.sourceNode.name} → ${link.targetNode.name}: ${link.value}`}</title>
                    //TODO 팝업메세지 나열
                    <title>
                        {(() => {
                            //TODO 1번째 구간 링크 정보를 담는 데이터
                            //TODO 각각의 정보들을 갖고 있는 배열에 대해서 같은 조건일 때 이어줘야하는 함수를 새로 또 만들어야 할 것 같아보인다.

                            //TODO 1번째 단위 기능 : <title/>에 문자열을 넣는 단위 기능 (e.g. 함수..) -> 완료
                            //TODO 2번째 단위 기능 : 링크 정보들을 찾는 단위 기능 (e.g. 함수..) -> 완료
                            //TODO 3번째 단위 기능 : 찾은 링크 정보들을 담는 데이터 구조 (e.g. 배열 등..)
                            //TODO 4번째 단위 기능 : 찾은 링크 정보들을 담은 데이터를 "1번째 단위 기능"에 전달하기 (e.g. 함수 등..
                            return titleTag();
                        })()}
                        {/* {(() => {
                                return '왼쪽 LINK 가 같은 process애들을 여기 함수에서 찾도록 한다.';
                            })()} */}
                    </title>
                ) : (
                    <title className="info"></title>
                    // <title>
                    //     {((arg, i) => {
                    //         const wantAnswer = findFrontLinks(arg);

                    //         let returns = () => {
                    //             if (link.target <= 30) {
                    //             }
                    //         };

                    //         return `왼쪽 LINK 가 같은 process애들을 여기 함수에서 찾도록 한다.`;
                    //     })()}
                    // </title>
                    // <>
                    //     <title>
                    //         {(() => {
                    //             return '왼쪽 LINK 가 같은 process애들을 여기 함수에서 찾도록 한다.';
                    //         })()}
                    //     </title>
                    // </>
                    // <h1>hello</h1>
                )}
            </path>
            {/* <Brushes /> */}
            {/* <Brush dimensions={dimensions.current} data={data} onBrushUpdateData={onBrushUpdateData} propertiesNames={propertiesNames} stroke="rgb(47, 74, 89)" /> */}
        </>
    );
};

function findFrontLinks(arg: { linkPart: SankeyLink; renderingData: SankeyData; interactionType?: 'hover' | 'click' }) {
    const { linkPart, renderingData, interactionType = 'click' } = arg;
    // console.log('asdf');
    // console.log(arg);
    // console.log(linkPart.valueid);
    const frontLinks = renderingData.links.filter((renderingLink) => {
        // if (renderingLink.target === linkPart.source && renderingLink.id === linkPart.id) {
        if (renderingLink.target === linkPart.source && renderingLink.paperName === linkPart.paperName) {
            // 하이라이팅 해야할 놈...

            // if (interactionType === 'hover') {
            //     renderingLink.color = 'targetHighlightLinkColor';
            //     console.log('hello');
            // } else if (interactionType === 'click') {
            //     renderingLink.color = 'targetLinkColor';
            //     console.log('nohello');
            // }

            if (renderingLink.target >= 0 && renderingLink.target <= 8) {
                renderingLink.color = 'targetLinkColor';
                //  renderingLink.valueid = 'selected';
                // renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
                renderingLink.status = 'selected';
            } else if (renderingLink.target >= 8 && renderingLink.target <= 10) {
                renderingLink.color = 'targetLinkOneColor';
                //  renderingLink.valueid = 'selected';
                // renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
                renderingLink.status = 'selected';
            } else if (renderingLink.target >= 11 && renderingLink.target <= 15) {
                renderingLink.color = 'targetLinkTwoColor';
                //  renderingLink.valueid = 'selected';
                // renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
                renderingLink.status = 'selected';
            } else if (renderingLink.target >= 16 && renderingLink.target <= 20) {
                renderingLink.color = 'targetLinkThreeColor';
                //  renderingLink.valueid = 'selected';
                // renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
                renderingLink.status = 'selected';
            } else if (renderingLink.target >= 21 && renderingLink.target <= 30) {
                renderingLink.color = 'targetLinkFourColor';
                //  renderingLink.valueid = 'selected';
                // renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
                renderingLink.status = 'selected';
            }
            if (renderingLink.target >= 31 && renderingLink.target <= 33) {
                renderingLink.color = 'intOneLinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            } else if (renderingLink.target === 34) {
                renderingLink.color = 'intOneLightLinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            } else if (renderingLink.source === 34) {
                renderingLink.color = 'intOneLightLinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            } else if (renderingLink.target === 35) {
                renderingLink.color = 'intOneLight2LinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            } else if (renderingLink.source === 35) {
                renderingLink.color = 'intOneLight2LinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            } else if (renderingLink.target >= 36 && renderingLink.target <= 38) {
                renderingLink.color = 'intOneLight3LinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            } else if (renderingLink.source >= 36 && renderingLink.source <= 38) {
                renderingLink.color = 'intOneLight3LinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            } else if (renderingLink.target === 39) {
                renderingLink.color = 'intTwoLinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            } else if (renderingLink.source === 39) {
                renderingLink.color = 'intTwoLinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            } else if (renderingLink.target === 40) {
                renderingLink.color = 'intTwoLightLinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            } else if (renderingLink.source === 40) {
                renderingLink.color = 'intTwoLightLinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            } else if (renderingLink.target === 41) {
                renderingLink.color = 'intThreeLinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            } else if (renderingLink.source === 41) {
                renderingLink.color = 'intThreeLinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            } else if (renderingLink.target === 42) {
                renderingLink.color = 'intThreeLightLinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            } else if (renderingLink.source === 42) {
                renderingLink.color = 'intThreeLightLinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            } else if (renderingLink.target === 43) {
                renderingLink.color = 'intThreeLight1LinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            } else if (renderingLink.source === 43) {
                renderingLink.color = 'intThreeLight1LinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            } else if (renderingLink.target === 44) {
                renderingLink.color = 'intThreeLight2LinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            } else if (renderingLink.source === 44) {
                renderingLink.color = 'intThreeLight2LinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            } else if (renderingLink.target === 45) {
                renderingLink.color = 'intFourLinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            } else if (renderingLink.source === 45) {
                renderingLink.color = 'intFourLinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            } else if (renderingLink.target === 46) {
                renderingLink.color = 'intFiveLinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            } else if (renderingLink.source === 46) {
                renderingLink.color = 'intFiveLinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            } else if (renderingLink.target >= 47 && renderingLink.target <= 48) {
                renderingLink.color = 'intFiveLightLinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            } else if (renderingLink.source >= 47 && renderingLink.source <= 48) {
                renderingLink.color = 'intFiveLightLinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            } else if (renderingLink.target === 49) {
                renderingLink.color = 'intFiveLight2LinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            } else if (renderingLink.source === 49) {
                renderingLink.color = 'intFiveLight2LinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            } else if (renderingLink.source >= 50 && renderingLink.source <= 75) {
                renderingLink.color = linkPart.color;
            } else if (renderingLink.target >= 50 && renderingLink.target <= 75) {
                renderingLink.color = linkPart.color;
            }
            return true;
        } else {
            return false;
        }
    });

    // console.log(frontLinks);

    frontLinks.forEach((linkPart) => {
        findFrontLinks({
            linkPart,
            renderingData,
        }); //recursive forward calculate function
    });

    // result.push (itself, othhers)

    // result.,foreahc
}

function findBackLinks(arg: { linkPart: SankeyLink; renderingData: SankeyData }) {
    const { linkPart, renderingData } = arg;
    const backLinks = renderingData.links.filter((renderingLink) => {
        // if (renderingLink.source === linkPart.target && renderingLink.id === linkPart.id) {
        // if (renderingLink.source === linkPart.target && renderingLink.paperName === linkPart.paperName) {
        //     if (renderingLink.source >= 50 && renderingLink.source <= 75) {
        //         renderingLink.color = linkPart.color;
        //     }
        //     if (renderingLink.target >= 50 && renderingLink.target <= 75) {
        //         renderingLink.color = linkPart.color;
        //     }
        //     if (renderingLink.target >= 76 && renderingLink.target < 83) {
        //         renderingLink.color = 'repVisVarColor';
        //         renderingLink.valueid = linkPart.valueid;
        //         //renderingLink.status = 'selected';
        //         renderingLink.paperName = linkPart.paperName;
        //         // renderingLink.process = linkPart.process;
        //     }
        //     if (renderingLink.target > 82 && renderingLink.target < 100) {
        //         renderingLink.color = 'repVisTechColor';
        //         renderingLink.valueid = linkPart.valueid;
        //         //renderingLink.status = 'selected';
        //         renderingLink.paperName = linkPart.paperName;
        //         // renderingLink.process = linkPart.process;
        //     }
        //     return true;
        // }
        if (renderingLink.source === linkPart.target && renderingLink.paperName === linkPart.paperName) {
            if (renderingLink.target >= 31 && renderingLink.target <= 33) {
                renderingLink.color = 'intOneLinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            }
            if (renderingLink.target === 34) {
                renderingLink.color = 'intOneLightLinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            }
            if (renderingLink.source === 34) {
                renderingLink.color = 'intOneLightLinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            }
            if (renderingLink.target === 35) {
                renderingLink.color = 'intOneLight2LinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            }
            if (renderingLink.source === 35) {
                renderingLink.color = 'intOneLight2LinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            }
            if (renderingLink.target >= 36 && renderingLink.target <= 38) {
                renderingLink.color = 'intOneLight3LinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            }
            if (renderingLink.source >= 36 && renderingLink.source <= 38) {
                renderingLink.color = 'intOneLight3LinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            }
            if (renderingLink.target === 39) {
                renderingLink.color = 'intTwoLinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            }
            if (renderingLink.source === 39) {
                renderingLink.color = 'intTwoLinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            }
            if (renderingLink.target === 40) {
                renderingLink.color = 'intTwoLightLinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            }
            if (renderingLink.source === 40) {
                renderingLink.color = 'intTwoLightLinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            }
            if (renderingLink.target === 41) {
                renderingLink.color = 'intThreeLinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            }
            if (renderingLink.source === 41) {
                renderingLink.color = 'intThreeLinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            }
            if (renderingLink.target === 42) {
                renderingLink.color = 'intThreeLightLinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            }
            if (renderingLink.source === 42) {
                renderingLink.color = 'intThreeLightLinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            }
            if (renderingLink.target === 43) {
                renderingLink.color = 'intThreeLight1LinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            }
            if (renderingLink.source === 43) {
                renderingLink.color = 'intThreeLight1LinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            }
            if (renderingLink.target === 44) {
                renderingLink.color = 'intThreeLight2LinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            }
            if (renderingLink.source === 44) {
                renderingLink.color = 'intThreeLight2LinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            }
            if (renderingLink.target === 45) {
                renderingLink.color = 'intFourLinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            }
            if (renderingLink.source === 45) {
                renderingLink.color = 'intFourLinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            }
            if (renderingLink.target === 46) {
                renderingLink.color = 'intFiveLinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            }
            if (renderingLink.source === 46) {
                renderingLink.color = 'intFiveLinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            }
            if (renderingLink.target >= 47 && renderingLink.target <= 48) {
                renderingLink.color = 'intFiveLightLinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            }
            if (renderingLink.source >= 47 && renderingLink.source <= 48) {
                renderingLink.color = 'intFiveLightLinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            }
            if (renderingLink.target === 49) {
                renderingLink.color = 'intFiveLight2LinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            }
            if (renderingLink.source === 49) {
                renderingLink.color = 'intFiveLight2LinkColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            }
            if (renderingLink.source >= 50 && renderingLink.source <= 75) {
                renderingLink.color = linkPart.color;
            }
            if (renderingLink.target >= 50 && renderingLink.target <= 75) {
                renderingLink.color = linkPart.color;
            }
            if (renderingLink.target >= 76 && renderingLink.target < 83) {
                renderingLink.color = 'repVisVarColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            }
            if (renderingLink.target > 82 && renderingLink.target < 100) {
                renderingLink.color = 'repVisTechColor';
                renderingLink.valueid = linkPart.valueid;
                //renderingLink.status = 'selected';
                renderingLink.paperName = linkPart.paperName;
                // renderingLink.process = linkPart.process;
            }
            return true;
        } else {
            return false;
        }
    });
    // console.log(backLinks);

    backLinks.forEach((linkPart) => {
        findBackLinks({
            linkPart,
            renderingData,
        }); //recursive backward calculate  function
    });
}

function findFrontLinkss(arg: { linkPart: SankeyLinkExtended; renderingDatas: SankeyLinkExtended; interactionType?: 'hover' | 'click' }) {
    const { linkPart, renderingDatas, interactionType = 'click' } = arg;
    console.log(linkPart);
    console.log(renderingDatas);
    // console.log('asdf');
    // console.log(arg);
    // console.log(linkPart.valueid);
    const afterLinks = [renderingDatas] as SankeyLinkExtended[];
    // console.log(renderingDatas);
    const frontLinkss = afterLinks.filter((recursiveLink) => {
        console.log(recursiveLink);
        // if (recursiveLink.target === linkPart.source && recursiveLink.id === linkPart.id) {
        if (recursiveLink.target === linkPart.source && recursiveLink.paperName === linkPart.paperName) {
            // 하이라이팅 해야할 놈...
            //TODO Interaction Type hover click이냐 frontLinks, backLinks에 추가하기.
            recursiveLink.sourceNode.name = linkPart.sourceNode.name;
            recursiveLink.sourceNode.name = linkPart.sourceNode.name;
            return true;
        } else {
            return false;
        }
    });

    // console.log(frontLinks);
    frontLinkss.forEach((linkPart) => {
        findFrontLinks({
            linkPart,
            //@ts-ignore
            renderingDatas,
        }); //recursive forward calculate function
    });
    // console.log(frontLinkss);
    // result.push (itself, othhers)

    // result.,foreahc
}

function findBackLinkss(arg: { linkPart: SankeyLinkExtended; renderingDatas: SankeyLinkExtended }) {
    const { linkPart, renderingDatas } = arg;
    const afterLinks = [renderingDatas] as SankeyLinkExtended[];
    const backLinkss = afterLinks.filter((recursiveLink) => {
        if (recursiveLink.target === linkPart.source && recursiveLink.paperName === linkPart.paperName) {
            recursiveLink.sourceNode.name = linkPart.sourceNode.name;
            recursiveLink.sourceNode.name = linkPart.sourceNode.name;
            return true;
        } else {
            return false;
        }
    });

    backLinkss.forEach((linkPart) => {
        findBackLinks({
            linkPart,
            //@ts-ignore
            renderingDatas,
        }); //recursive backward calculate  function
    });
    // console.log(backLinks);
}
