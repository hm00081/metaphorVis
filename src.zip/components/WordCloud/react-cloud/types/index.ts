export type { WordData } from './word';
