export const Target = `
Opinion Opinion Opinion Opinion
Evaluation Evaluation Evaluation Evaluation Evaluation
Emotion Emotion Emotion Emotion
Tweets Tweets Tweets Tweets
Writer
Writing
Incident
Time Time Time Time
Article Article Article
Accumulation
the subject
Height
People
User
Service
Start
Writer Writer Writer
Subject Subject  Subject
Continuity
extinction
reduction in size
the product
Growth
Word
Place
Player
Relevant
Target
Posting
the Grand National Party
Property
Position
Topic
an accident
Attitude
Process
Article
User
Combined
Expression
Retweet
Period
Collection
Community
Mention
Debate
Specific
Psychology
Review
Change
writing out
Repetition
Ordinary person
Group
Comments
Bank
Candidate
Text
Sharing
Continuous
Behavior
Politician
Several
Record
Blog
Comments
Pattern
Personality
Message
Progress
Diffusion
Electronic devices
Frequency
Video
Flow
long axis
Appearance
Data
Romney
Information
Water
The Obamas
Event
Photographs
vocabulary
News
the United States
Post
Social
polarity
Trump
meeting
Celebrity
Teg
implication
Hash
Occurrence
therefore
Including
Satisfaction level
Utilization
Scene
Media
`;

export const Intermediation = `
Opinion
Time Time Time Time Time
Analysis
Search
Emotion
Tweets Tweets Tweets Tweets
Analysis Analysis Analysis
Information
Comparison
Emotional
vision
User
Height
Word
Pattern
Each other
polarity
Evaluation
Summary
content
Classification
Text
a ship's
Several
Data
Change
Posting
Relevant
People
Target
User
Realize
Diffusion
Detection
News
Process
Collection
Through
Writing
Character
Event
Topic
Incident
different
Activity
Record
individual
arrangement
Group
Review
Topic
Level
Writer.
Service
Specific
Flow
Sensing
the product
that
Provision
Rumor
a passage at arms
Bank
Social
Including
President
Two
Stars
Occurrence
Perspective
section
Post
Retention
Check.
aspect
Relationship
Comments
Period
Description
Water
Branch
Property
a split
Comments
Accumulation
Article
Media
Institution
relevant
sheep
Behavior
Community
Blog
Message
vocabulary
Work
Evidence
Processing
Publishing
Utilization
Retweet

`;

export const Representation = `
Tweets
Time
Opinion
Emotion
Information
natural phenomenon
Height
geometry
Shapes
One.
Change
Saint
Substance
Flow
Plants
Expression
Bubble
Word
Pattern
polarity
User
the arm of the law
creation
User
a compound
therefore
Diffusion
Branch
Tree
Topic
Posting
Specific
Nature
Pure
River
Formation
Evaluation
Connection
Building
Pattern.
Relationship
Retweet
Mooring
Wheel
Article
Decoration
Record
vision
Group
Map
sheep
deposition
Stem
Form
vocabulary
Behavior
extinction
Time and space
a split
Relevant
Between
application
Comments
Growth
Target
Accumulation
Frequency
Post
water
participant
Leaves
different
Above
Message
Petal
Topic
Two
Display
Occurrence
Retention
Including
Process
Text
Structure
a tribute
Activity
Use
Emotional
Artificiality
Leg
Line
Location
Each other
Wheels
Period
the water of water
an emoji
Case
flower
Progress

`;

export const Visvar = `
Color
Size
therefore
Change
Location
Word
Height
polarity
Emotion
Denial
Positive
Opinion
Tweets
light and shade
Direction
Lecture
Colors
Red
Shape
User
Time
Green
Width
neutrality
Pattern
Area
Mention
Decision
Including
Frequency
In the album
Each other
different
degree
Text
Bubble
Branch
Use
Yellow
Collection
Expression
Strength
Article
Blue
Series
sheep
Center
Case
Branch
the other side
Specific
Feather
Comments
Relevant
Petal
Appears
Appearance
Two
Information
The number
Leaf
Relationship
Community
Group
Height
participant
Evaluation
Orange
Between
Posting
kind
Change
Value
Degree
User
relevant
luggage
Phosphate
area
Poetry
Camp
People
Node
Progress
Connection
Below.
Period
Event
Emotional
Topic
Distance
I ordered
Above
Proportional
Brand
Circle
Red
block
News
The score

`;

export const Vistech = `

vision
Time
Word
Form
Height
Pattern
Tweets
Emotion
Bubble
Text
Node
Chart
Use
sheep
Collection
The Cloud
polarity
Change
Frequency
Opinion
Link
Information
User
Mention
Major
Specific
Period
Data
Accumulation
Diagram
area
Size
foundation
Comments
The trend
Stove
Plot
Relevant
Flow
section
Through
Distribution
Realize
vocabulary
Message
Graph
Retweet
Topic
Expression
therefore
Group
Pie
Line
Include
Order
Heat Map
Ship
Hierarchy
Posting
Display
Target
Record
Relationship
User
News
Utterance
People
Amount
Teg
Space
content
differently
Topic
Comparison
Activity
Comments
Location
Evaluation
Bank
Scatterplot
Color
Rumor
Dispute
Behavior
Sharing
Incident
Box
Suggest
Community
Only
Event
Stars
Difference
Appearance
a stick
Review
deposition
Map
Occurrence
Stack


`;
