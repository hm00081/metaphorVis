export const calcGraph = () => {};
