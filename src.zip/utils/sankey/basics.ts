import { SankeyLinkExtended } from '../../types';

export namespace Utility {}
